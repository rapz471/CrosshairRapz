# RAPZ CROSSHAIR

Android project untuk crosshair visual overlay.

## Fitur
- 4 bentuk crosshair
- 6 warna
- slider ukuran
- slider transparansi
- overlay di tengah layar
- foreground notification agar overlay lebih stabil
- tidak mengubah file Free Fire, tidak auto-aim, tidak injector

## Build
1. Buka folder ini di Android Studio.
2. Tunggu Gradle sync selesai.
3. Pilih Build > Build APK(s).
4. Install APK debug ke HP.
5. Saat aplikasi dibuka, izinkan "tampil di atas aplikasi lain".
6. Pilih crosshair/warna lalu aktifkan overlay.

Catatan: Android versi tertentu dapat meminta izin notifikasi untuk foreground service.
