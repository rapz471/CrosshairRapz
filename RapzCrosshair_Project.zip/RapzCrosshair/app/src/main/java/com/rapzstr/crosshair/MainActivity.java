package com.rapzstr.crosshair;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root;
    int purple = Color.rgb(155,77,255);
    int[] colors = {Color.WHITE, Color.RED, Color.GREEN, Color.CYAN, Color.YELLOW, Color.rgb(255,0,180)};
    int selectedColor = Color.GREEN;
    int selectedStyle = 0;
    int size = 110;
    int alpha = 230;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    TextView tv(String s, float sp) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp); t.setPadding(0,8,0,8); return t;
    }
    GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g;
    }
    Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(bg(Color.rgb(35,27,55), 28));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 52); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b;
    }

    void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,20,24,20); root.setBackgroundColor(Color.rgb(8,7,17));
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);

        TextView title = tv("✦  RAPZ CROSSHAIR", 26); title.setTextColor(Color.rgb(190,130,255)); root.addView(title);
        TextView sub = tv("Visual crosshair overlay • simple & clean", 13); sub.setTextColor(Color.LTGRAY); root.addView(sub);

        Button permission = button("⚙  Izinkan tampil di atas aplikasi");
        permission.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= 23) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
        }); root.addView(permission);

        root.addView(tv("PILIH CROSSHAIR", 15));
        LinearLayout styles = new LinearLayout(this); styles.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"＋", "✦", "⊕", "✕"};
        for (int i=0;i<4;i++) { final int x=i; Button b=button(names[i]); b.setTextSize(25); b.setOnClickListener(v->{selectedStyle=x;}); styles.addView(b,new LinearLayout.LayoutParams(0,70,1)); }
        root.addView(styles);

        root.addView(tv("WARNA", 15));
        LinearLayout cols = new LinearLayout(this); cols.setOrientation(LinearLayout.HORIZONTAL);
        for (int c: colors) { final int cc=c; Button b=button("●"); b.setTextColor(c); b.setTextSize(24); b.setOnClickListener(v->{selectedColor=cc;}); cols.addView(b,new LinearLayout.LayoutParams(0,65,1)); }
        root.addView(cols);

        root.addView(tv("UKURAN", 15)); SeekBar sizeBar=new SeekBar(this); sizeBar.setMax(180); sizeBar.setProgress(85); sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){size=50+p;}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}}); root.addView(sizeBar);
        root.addView(tv("TRANSPARANSI", 15)); SeekBar alphaBar=new SeekBar(this); alphaBar.setMax(255); alphaBar.setProgress(alpha); alphaBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){alpha=Math.max(40,p);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}}); root.addView(alphaBar);

        Button start=button("🎯  AKTIFKAN OVERLAY"); start.setTextColor(Color.WHITE); start.setBackground(bg(purple,30)); start.setOnClickListener(v->startOverlay()); root.addView(start);
        Button stop=button("✕  MATIKAN OVERLAY"); stop.setOnClickListener(v->stopService(new Intent(this,OverlayService.class))); root.addView(stop);
        TextView note=tv("Catatan: aplikasi ini hanya menampilkan crosshair visual di atas aplikasi lain. Tidak mengubah file/game, auto-aim, atau injector.",12); note.setTextColor(Color.GRAY); note.setPadding(0,18,0,0); root.addView(note);
    }

    void startOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this,"Izinkan overlay dulu ya",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); return;
        }
        Intent i=new Intent(this,OverlayService.class); i.putExtra("style",selectedStyle); i.putExtra("color",selectedColor); i.putExtra("size",size); i.putExtra("alpha",alpha);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        Toast.makeText(this,"Crosshair aktif 🎯",Toast.LENGTH_SHORT).show();
    }
}
