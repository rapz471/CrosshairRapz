package com.rapzstr.crosshair;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
    WindowManager wm; CrosshairView view; int style,color,size,alpha;
    final String CH="rapz_crosshair";

    @Override public void onCreate(){ super.onCreate();
        if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel(CH,"Rapz Crosshair",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager.class).createNotificationChannel(c); }
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        style=i.getIntExtra("style",0); color=i.getIntExtra("color",Color.GREEN); size=i.getIntExtra("size",110); alpha=i.getIntExtra("alpha",230);
        if(Build.VERSION.SDK_INT>=26){ Notification n=new Notification.Builder(this,CH).setContentTitle("Rapz Crosshair").setContentText("Crosshair overlay sedang aktif").setSmallIcon(android.R.drawable.ic_menu_compass).setOngoing(true).build(); startForeground(7,n); }
        show(); return START_STICKY;
    }
    void show(){ if(view!=null)return; wm=(WindowManager)getSystemService(WINDOW_SERVICE); view=new CrosshairView(this);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(size,size,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT); p.gravity=Gravity.CENTER; wm.addView(view,p);
    }
    @Override public void onDestroy(){if(view!=null){try{wm.removeView(view);}catch(Exception e){} view=null;} super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}

    class CrosshairView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); float d;
        CrosshairView(Context c){super(c); d=getResources().getDisplayMetrics().density; p.setStrokeCap(Paint.Cap.SQUARE); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){ super.onDraw(c); float cx=getWidth()/2f, cy=getHeight()/2f; float r=getWidth()*.34f; p.setColor(color); p.setAlpha(alpha); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(2,getWidth()*.035f)); p.setShadowLayer(8,0,0,color);
            if(style==0){c.drawLine(cx-r,cy,cx-r*.25f,cy,p);c.drawLine(cx+r*.25f,cy,cx+r,cy,p);c.drawLine(cx,cy-r,cx,cy-r*.25f,p);c.drawLine(cx,cy+r*.25f,cx,cy+r,p);}
            else if(style==1){Path q=new Path();q.moveTo(cx,cy-r);q.lineTo(cx+r*.22f,cy-r*.22f);q.lineTo(cx+r,cy);q.lineTo(cx+r*.22f,cy+r*.22f);q.lineTo(cx,cy+r);q.lineTo(cx-r*.22f,cy+r*.22f);q.lineTo(cx-r,cy);q.lineTo(cx-r*.22f,cy-r*.22f);q.close();c.drawPath(q,p);}
            else if(style==2){c.drawCircle(cx,cy,r*.72f,p);c.drawLine(cx-r,cy,cx+r,cy,p);c.drawLine(cx,cy-r,cx,cy+r,p);}
            else {c.drawLine(cx-r,cy-r,cx-r*.2f,cy-r*.2f,p);c.drawLine(cx+r,cy-r,cx+r*.2f,cy-r*.2f,p);c.drawLine(cx-r,cy+r,cx-r*.2f,cy+r*.2f,p);c.drawLine(cx+r,cy+r,cx+r*.2f,cy+r*.2f,p);}
        }
    }
}
